using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Collections.Generic;

namespace hihi.Pages
{
    public class IndexModel : PageModel
    {
        public List<Movie> Movies { get; set; } = new List<Movie>();

        public static List<Movie> MoviesData = new List<Movie>();

        public void OnGet()
        {
            Movies = MoviesData;
        }
    }
}
