using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Linq;

namespace hihi.Pages
{
    public class DeleteModel : PageModel
    {
        public Movie? Movie { get; set; }  

        public IActionResult OnGet(int id)
        {
            Movie = IndexModel.MoviesData.FirstOrDefault(m => m.Id == id);

            if (Movie == null)
            {
                return RedirectToPage("Index");
            }

            return Page();
        }

        public IActionResult OnPost(int id)
        {
            var movieToDelete = IndexModel.MoviesData.FirstOrDefault(m => m.Id == id);

            if (movieToDelete != null)
            {
                IndexModel.MoviesData.Remove(movieToDelete);
            }

            return RedirectToPage("Index");
        }
    }
}
