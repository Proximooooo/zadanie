using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;

namespace hihi.Pages
{
    public class CreateModel : PageModel
    {
        [BindProperty]
        public Movie Movie { get; set; } = new Movie(); 

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            if (IndexModel.MoviesData == null)
            {
                IndexModel.MoviesData = new List<Movie>();
            }

            Movie.Id = IndexModel.MoviesData.Count + 1;
            IndexModel.MoviesData.Add(Movie);

            return RedirectToPage("Index");
        }
    }
}
