using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Linq;

namespace hihi.Pages
{
    public class DetailsModel : PageModel
    {
        public Movie? Movie { get; set; }

        public IActionResult OnGet(int id)
        {
            Movie = IndexModel.MoviesData.FirstOrDefault(m => m.Id == id);

            if (Movie == null)
            {
                return RedirectToPage("Index");
            }

            return Page();
        }
    }
}
