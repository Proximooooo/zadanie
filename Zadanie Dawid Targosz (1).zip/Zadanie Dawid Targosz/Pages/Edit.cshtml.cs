using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using hihi.Models;
using System.Linq;

namespace hihi.Pages
{
    public class EditModel : PageModel 
    {
        [BindProperty]
        public Movie? Movie { get; set; }

        public IActionResult OnGet(int id)
        {
            Movie = IndexModel.MoviesData.FirstOrDefault(m => m.Id == id);

            if (Movie == null)
            {
                return RedirectToPage("Index");
            }

            return Page();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var movieToUpdate = IndexModel.MoviesData.FirstOrDefault(m => m.Id == Movie?.Id);

            if (movieToUpdate != null && Movie != null)
            {
                movieToUpdate.Name = Movie.Name;
                movieToUpdate.Description = Movie.Description;
                movieToUpdate.Price = Movie.Price;
            }

            return RedirectToPage("Index");
        }
    }
}
